import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  FlatList,
  TouchableOpacity,
} from "react-native";
import { MaterialIcons, Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";

export default function InfoChat({ route }) {
  const { conversation, currentUser, otherUser } = route.params;
  const navigation = useNavigation();

  const isGroup = conversation.isGroup;
  const [showOptionsFor, setShowOptionsFor] = useState(null);

  console.log(conversation);

  const handleGoBack = () => {
    navigation.goBack();
  };

  const handleCreateGroup = () => {
    navigation.navigate("CreateGroupScreen", {
      currentUser,
      selectedUser: otherUser,
    });
  };

  const renderMember = ({ item }) => {
    const isLeader = conversation.groupLeader === item._id;
    const isOptionsOpen = showOptionsFor === item._id;

    return (
      <View style={styles.memberContainer}>
        <View style={styles.memberInfo}>
          <Image source={{ uri: item.avatar }} style={styles.avatar} />
          <View>
            <Text style={styles.username}>
              {item.username}
              {isLeader && <Text style={styles.roleText}>👑 Nhóm trưởng</Text>}
            </Text>
          </View>
        </View>

        <TouchableOpacity
          onPress={() =>
            setShowOptionsFor((prev) => (prev === item._id ? null : item._id))
          }
        >
          <Ionicons name="ellipsis-vertical" size={20} color="gray" />
        </TouchableOpacity>

        {isOptionsOpen && (
          <View style={styles.optionsBox}>
            {isLeader ? (
              <Text style={styles.leaderText}>👑 Nhóm trưởng</Text>
            ) : (
              <>
                <TouchableOpacity
                  onPress={() => {
                    console.log("Cấp quyền phó nhóm cho", item.username);
                    setShowOptionsFor(null);
                  }}
                >
                  <Text style={styles.optionText}>✨ Cấp quyền phó nhóm</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => {
                    console.log("Xoá khỏi cuộc trò chuyện:", item.username);
                    setShowOptionsFor(null);
                  }}
                >
                  <Text style={[styles.optionText, { color: "red" }]}>
                    ❌ Xóa khỏi cuộc trò chuyện
                  </Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        )}
      </View>
    );
  };

  return (
    <View style={styles.container}>
      {/* Thêm nút quay lại */}
      <TouchableOpacity onPress={handleGoBack} style={styles.backButton}>
        <Ionicons name="arrow-back" size={24} color="black" />
      </TouchableOpacity>

      <Text style={styles.title}>
        {isGroup ? "Thông tin nhóm" : otherUser.username}{" "}
        {/* Hiển thị tên người dùng nếu không phải nhóm */}
      </Text>

      {isGroup ? (
        <>
          <Text style={styles.sectionTitle}>Danh sách thành viên</Text>
          <FlatList
            data={conversation.members}
            keyExtractor={(item) => item._id}
            renderItem={renderMember}
            contentContainerStyle={{ paddingBottom: 20 }}
          />

          <TouchableOpacity
            style={styles.addMemberBtn}
            onPress={() =>
              navigation.navigate("AddMemberScreen", { conversation })
            }
          >
            <Ionicons name="person-add" size={24} color="#007bff" />
            <Text style={styles.addMemberText}>Thêm thành viên</Text>
          </TouchableOpacity>
        </>
      ) : (
        <>
          <View style={styles.singleUserInfo}>
            <Image
              source={{ uri: otherUser.avatar }}
              style={styles.avatarLarge}
            />
            <Text style={styles.username}>{otherUser.username}</Text>
          </View>
          <TouchableOpacity
            style={styles.createGroupBtn}
            onPress={handleCreateGroup}
          >
            <MaterialIcons name="group-add" size={24} color="white" />
            <Text style={styles.btnText}>Tạo nhóm với người này</Text>
          </TouchableOpacity>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: "white",
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "600",
    marginBottom: 8,
  },
  memberContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },
  avatar: {
    width: 42,
    height: 42,
    borderRadius: 21,
    marginRight: 12,
  },
  avatarLarge: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginBottom: 12,
  },
  username: {
    fontSize: 16,
  },
  singleUserInfo: {
    alignItems: "center",
    marginTop: 20,
  },
  createGroupBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 24,
    backgroundColor: "#007bff",
    paddingVertical: 12,
    borderRadius: 8,
  },
  btnText: {
    color: "white",
    marginLeft: 8,
    fontSize: 16,
  },
  addMemberBtn: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },
  addMemberText: {
    fontSize: 16,
    color: "#007bff",
    marginLeft: 6,
  },
  memberInfo: {
    flexDirection: "row",
    alignItems: "center",
  },
  optionsBox: {
    backgroundColor: "#f0f0f0",
    padding: 8,
    borderRadius: 6,
    marginTop: 8,
    marginLeft: 54,
  },
  optionText: {
    fontSize: 14,
    paddingVertical: 4,
  },
  leaderText: {
    fontSize: 14,
    fontWeight: "600",
    color: "#333",
  },
  backButton: {
    padding: 8,
    position: "absolute",
    top: 16,
    left: 16,
    zIndex: 10,
  },
});
